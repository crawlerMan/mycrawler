from instabot import Bot
import time
from textblob import TextBlob
import re
import emoji
from bson.binary import Binary
import requests
import os
from collections import Counter
import datetime


#-------------MongoDB Config-------------#

from pymongo import MongoClient
client = MongoClient('localhost')
db = client.InstagramCrawl

#--------------*****----------------------#


#--------------Log maker function----------------------#
def logmaker(bot="insta",kind=" ",description=" "):
	date = datetime.datetime.now()
	title = "Date:      Time:          " + "\t" + "Kind:" + "\t" + "Description:" + "\t" + "\n"
	log = str(date) + "\t" + str(kind) + "\t" + str(description) + "\t" + "\n"

	if bot =="fb":
		if os.path.exists("fbLog.txt"):
			logFile = open("fbLog.txt", "a+")
			logFile.write(log)
			logFile.close()

		else:
			with open("fbLog.txt", "w") as NewlogFile:
				NewlogFile.write(title)
				NewlogFile.write(log)
				NewlogFile.close()
	elif bot == "insta":
		if os.path.exists("/Users/vahid/Downloads/instaLog.txt"):
			logFile = open("/Users/vahid/Downloads/instaLog.txt", "a+")
			logFile.write(log)
			logFile.close()

		else:
			with open("/Users/vahid/Downloads/instaLog.txt", "w") as NewlogFile:
				NewlogFile.write(title)
				NewlogFile.write(log)
				NewlogFile.close()

	elif bot == "telegram":
		if os.path.exists("telegramLog.txt"):
			logFile = open("telegramLog.txt", "a+")
			logFile.write(log)
			logFile.close()

		else:
			with open("telegramLog.txt", "w") as NewlogFile:
				NewlogFile.write(title)
				NewlogFile.write(log)
				NewlogFile.close()


#--------------Log maker function----------------------#



#-------------Kafka Config----------------#

from kafka import KafkaProducer, KafkaConsumer
import json

def kafkaproducer(jsn,topic,brokers = 'localhost:9092'):
    pass
    try:
        producer = KafkaProducer(bootstrap_servers=brokers, value_serializer=lambda v: json.dumps(v).encode('windows-1256'))
        msg = producer.send(topic, jsn)
        producer.flush()
    except:
        print("Somethings went wrong")
        print("plz Check Kafka connections...")
        logmaker(bot="insta", kind="error", description="kafka connections error ")
        time.sleep(10)
        pass

#--------------*****----------------------#

bot = Bot()

def resume():
    try:
        if os.path.exists("resume.txt"):
            f = open("resume.txt", "r")
            if f.mode == "r":
                x = f.readlines()

                for i in range(len(x)):
                    x[i]=removeStr(x[i])

                if len(x) == 0:
                    return None

                else:
                    return x





        else:
            print("resume file not found!")
            return 0,0,0

    except:
        print("somthings wrongs in resume...!")


def crawler(username,type = None, list=None):

    if type == None:
        getfollowingListInfo(username)
        getfollowerListInfo(username)

    elif type == "Followers":
        getfollowingListInfo(username,list)

    elif type == "Followings":
        getfollowerListInfo(username,list)



def checkout(username):
    try:
        print("check %s in database..." % username)
        find = db.instagram_users.find({"username": username}).count()
        findc = db.instagram_users.find({"username": username, "FFcrawlStatus": True}).count()

    except:
        print("Somethings in database was wrongs...")

    try:
        if findc == 0 and find >= 0 :
            print("%s was not crawled." % username)
            return True
        if findc >= 1:
            print("%s was  crawled." % username)
            return False

    except:
        print("Somethings was wrong!")
        pass


def startFunc():

    while True:
        username = input("plz type an username: \t")
        if checkout(username):
            try:
                data={"username": username, "FFcrawlStatus": False}
                x = db.instagram_users.insert_one(data)
                kafkaproducer(jsn={"collections": "instagram_users", "data": data}, topic="instagram_bot")
                logmaker(bot="insta", kind="log", description="instagram_users send to kafka 160")
                print("Start crawling %s " %username)
                crawler(username=username)
                update = db.instagram_users.update({"username":username}, {"$set": {"FFcrawlStatus": True}})
            except:
                print("Somethings in database was wrong....")
            break
        else:
            print("This username was crawled.\n")
            t = input("Do you want to try again?!(reply y or n)")
            if t == "y" or "yes" or "Y" or "Yes":
                pass
            else:
                break



def main(ip):

    if ip == 1:
        print("resume...")
        x = resume()
        if x == None:
            print("resume not found...\n")
            time.sleep(1)
            ip = input("""Choose one of them(Type number):
                    2 - type an username...
                    3 - Auto find username from database...\n""")

            main(int(ip))

        else:
            if len(x) <= 2 and len(x) > 0:
                username = x[0]
                types = x[1]
                lists = None

                if types == "crawler":
                    pass
                elif types == "Following" or "Followers":
                    crawler(username=username, type=types, list=lists)

            if len(x) > 2:
                username = x[0]
                types = x[1]
                lists = x[2:]

                if types == "crawler":
	                pass
                elif types == "Following" or "Followers":
                    crawler(username=username, type=types, list=lists)




    if ip == 2:
        startFunc()


    if ip == 3:

        print("search for username in database...")
        while True:
            find = db.instagram_users.find({"FFcrawlStatus": False})
            findc = db.instagram_users.find({"FFcrawlStatus": False}).count()
            if findc == 0:
                print("can not find any username in database...\n")
                startFunc()
            elif findc > 0:
                for i in find:
                    print("Start crawling %s" % i["username"])
                    crawler(i["username"])
                    update = db.instagram_users.update({"username":i["username"]}, {"$set": {"crawlStatus": True}})







#remove list b from list a
def modification(a,b):
    for x in b:
        try:
            a.remove(int(x))
        except ValueError:
            pass
    return a




def getfollowingListInfo(username,list = None):
    user_id =bot.get_user_id_from_username(username)
    f = open("resume.txt", "w+")
    f.write(username + '\n' + "Following")
    f.close()

    following = bot.get_user_following(username)

    #agar hich listi naashtim
    if list == None:
        if len(following) > 0:
            data = {"username": username, "user_id":int(user_id),"following_list": following}
            i = db.instagram_users_list.insert_one(data)
            kafkaproducer(jsn={"collections": "instagram_users_list", "data": data}, topic="instagram_bot")
            logmaker(bot="insta", kind="log", description="instagram_users_list send to kafka 266")
            y = 0
            g = 1
            for e in following:
                t = db.instagram_users.find({"owner": username, "type": "following", "user_id": int(e)}).count()
                if t == 0:
                    following_de = bot.get_user_info(e)
                    # print(following_de)
                    o = following_de
                    D = {"owner": username, "type": "following", "username": o["username"], "user_id": int(e),
                         "full_name": o["full_name"], "is_private": o["is_private"],
                         "follower_count": o["follower_count"], "following_count": o["following_count"],
                         "biography": o["biography"], "linke": o["external_url"], "profile_pic": o["profile_pic_url"]}
                    i = db.instagram_users_info.insert_one(D)
                    kafkaproducer(jsn={"collections": "instagram_users_info", "data": D}, topic="instagram_bot")
                    logmaker(bot="insta", kind="log", description="instagram_users_info send to kafka 282")


                    #sakhtan e listi az followers and followings
                    user_ff = db.instagram_users_ff.find({"username":o["username"]}).count()
                    if user_ff == 0:
                        following_l = bot.get_user_following(o["username"])
                        if len(following_l) > 0:
                            follower_l = bot.get_user_followers(o["username"])
                            data2 = {"username": o["username"], "user_id": int(e), "following": following_l,
                                     "follower": follower_l}
                            i = db.instagram_users_ff.insert_one(data2)
                            kafkaproducer(jsn={"collections": "instagram_users_ff", "data": data2}, topic="instagram_bot")
                            logmaker(bot="insta", kind="log", description="instagram_users_ff send to kafka 295")


                    print("\n")
                    print(str(g) + " - ")
                    g = g + 1
                    y = y + 1
                    print("owner:%s" % username)
                    print("username:%s" % o["username"])

                    f = open("resume.txt", "a+")
                    f.write('\n' + str(e))
                    f.close()

                    find = db.instagram_users.find({"username": o["username"]}).count()
                    if find == 0:
                        data={"username": o["username"], "crawlStatus": False}
                        i2 = db.instagram_users.insert(data)
                        kafkaproducer(jsn={"collections": "instagram_users", "data": data}, topic="instagram_bot")
                        logmaker(bot="insta", kind="log", description="instagram_users send to kafka 300")
                    time.sleep(10)
                    if y > 70:
                        time.sleep(360)
                        y = 0
                        continue
                else:
                    continue
        else:
            d = {"owner": username, "following list zero": True}
            o = db.instagram_skip_list.insert_one(d)
            kafkaproducer(jsn={"collections": "instagram_skip_list", "data": d}, topic="instagram_bot")
            logmaker(bot="insta", kind="log", description="instagram_skip_list send to kafka 311")



    #agar list dashtim
    else:
        for i in list:
            print("Skip username: %s:" % i)

            #hazf az list
            following = modification(following,list)
            y = 0
            g = 1
            for e in following:
                t = db.instagram_users.find({"owner": username, "type": "following", "user_id": int(e)}).count()
                if t == 0:
                    following_de = bot.get_user_info(e)
                    # print(following_de)
                    o = following_de
                    D = {"owner": username, "type": "following", "username": o["username"], "user_id": int(e),
                         "full_name": o["full_name"], "is_private": o["is_private"],
                         "follower_count": o["follower_count"], "following_count": o["following_count"],
                         "biography": o["biography"], "linke": o["external_url"], "profile_pic": o["profile_pic_url"]}
                    i = db.instagram_users_info.insert_one(D)
                    kafkaproducer(jsn={"collections": "instagram_users_info", "data": D}, topic="instagram_bot")
                    logmaker(bot="insta", kind="log", description="instagram_users_info send to kafka 337")

                    # sakhtan e listi az followers and followings
                    user_ff = db.instagram_users_ff.find({"username": o["username"]}).count()
                    if user_ff == 0:
                        following_l = bot.get_user_following(o["username"])
                        if len(following_l) > 0:
                            follower_l = bot.get_user_followers(o["username"])
                            data2 = {"username": o["username"], "user_id": int(e), "following": following_l,
                                     "follower": follower_l}
                            i = db.instagram_users_ff.insert_one(data2)
                            kafkaproducer(jsn={"collections": "instagram_users_ff", "data": data2},
                                          topic="instagram_bot")
                            logmaker(bot="insta", kind="log", description="instagram_users_ff send to kafka 366")

                    print("\n")
                    print(str(g) + " - ")
                    g = g + 1
                    y = y + 1
                    print("owner:%s" % username)
                    print("username:%s" % o["username"])

                    f = open("resume.txt", "a+")
                    f.write('\n' + str(e))
                    f.close()

                    find = db.instagram_users.find({"username": o["username"]}).count()
                    if find == 0:
                        data={"username": o["username"], "crawlStatus": False}
                        i2 = db.instagram_users.insert(data)
                        kafkaproducer(jsn={"collections": "instagram_users", "data": data}, topic="instagram_bot")
                        logmaker(bot="insta", kind="log", description="instagram_users send to kafka 354")

                    time.sleep(10)
                    if y > 70:
                        time.sleep(360)
                        y = 0
                        continue
                else:
                    continue
        else:
            d = {"owner": username, "following list zero": True}
            o = db.instagram_skip_list.insert_one(d)
            kafkaproducer(jsn={"collections": "instagram_skip_list", "data": d}, topic="instagram_bot")
            logmaker(bot="insta", kind="log", description="instagram_skip_list send to kafka 367")


def getfollowerListInfo(username,list = None):
    user_id =bot.get_user_id_from_username(username)

    f = open("resume.txt", "w+")
    f.write(username + '\n' + "Followers")
    f.close()

    follower = bot.get_user_followers(username)

    if list == None:
        if len(follower) > 0:
            data = {"username": username, "user_id":int(user_id),"follower_list": follower}
            i = db.instagram_user_follower_userid.insert_one(data)
            kafkaproducer(jsn={"collections": "instagram_user_follower_userid", "data": data}, topic="instagram_bot")
            logmaker(bot="insta", kind="log", description="instagram_user_follower_userid send to kafka 384")

            # for r in following:
            #    l = r
            y = 0
            g = 1
            for e in follower:
                t = db.instagram_users.find({"owner": username, "type": "follower", "user_id": int(e)}).count()
                if t == 0:
                    following_de = bot.get_user_info(e)
                    # print(following_de)
                    o = following_de
                    D = {"owner": username, "type": "follower", "username": o["username"], "user_id": int(e),
                         "full_name": o["full_name"], "is_private": o["is_private"],
                         "follower_count": o["follower_count"], "following_count": o["following_count"],
                         "biography": o["biography"], "linke": o["external_url"], "profile_pic": o["profile_pic_url"]}
                    i = db.instagram_users.insert_one(D)
                    kafkaproducer(jsn={"collections": "instagram_users", "data": D},
                                  topic="instagram_bot")
                    logmaker(bot="insta", kind="log", description="instagram_users send to kafka 404")

                    # sakhtan e listi az followers and followings
                    user_ff = db.instagram_users_ff.find({"username": o["username"]}).count()
                    if user_ff == 0:
                        following_l = bot.get_user_following(o["username"])
                        if len(following_l) > 0:
                            follower_l = bot.get_user_followers(o["username"])
                            data2 = {"username": o["username"], "user_id": int(e), "following": following_l,
                                     "follower": follower_l}
                            i = db.instagram_users_ff.insert_one(data2)
                            kafkaproducer(jsn={"collections": "instagram_users_ff", "data": data2},
                                          topic="instagram_bot")
                            logmaker(bot="insta", kind="log", description="instagram_users_ff send to kafka 445")

                    print("\n")
                    print(str(g) + " - ")
                    g = g + 1
                    y = y + 1
                    print("owner:%s" % username)
                    print("username:%s" % o["username"])

                    f = open("resume.txt", "a+")
                    f.write('\n' + str(e))
                    f.close()

                    find = db.instagram_users.find({"username": o["username"]}).count()
                    if find == 0:
                        data={"username": o["username"], "crawlStatus": False}
                        i2 = db.instagram_users.insert(data)
                        kafkaproducer(jsn={"collections": "instagram_users", "data": data},
                                      topic="instagram_bot")
                        logmaker(bot="insta", kind="log", description="instagram_users send to kafka 423")

                    time.sleep(10)
                    if y > 70:
                        time.sleep(360)
                        y = 0
                        continue
                else:
                    continue
        else:
            d = {"owner": username, "follower list zero": True}
            o = db.instagram_skip_list.insert_one(d)
            kafkaproducer(jsn={"collections": "instagram_skip_list", "data": d},
                          topic="instagram_bot")
            logmaker(bot="insta", kind="log", description="instagram_skip_list send to kafka 435")



    else:
        for i in list:
            print("Skip username: %s:" % i)

            # hazf az list
            follower = modification(follower, list)

            y = 0
            g = 1
            for e in follower:
                t = db.instagram_users.find({"owner": username, "type": "follower", "user_id": int(e)}).count()
                if t == 0:
                    following_de = bot.get_user_info(e)
                    # print(following_de)
                    o = following_de
                    D = {"owner": username, "type": "follower", "username": o["username"], "user_id": int(e),
                         "full_name": o["full_name"], "is_private": o["is_private"],
                         "follower_count": o["follower_count"], "following_count": o["following_count"],
                         "biography": o["biography"], "linke": o["external_url"], "profile_pic": o["profile_pic_url"]}
                    i = db.instagram_users.insert_one(D)
                    kafkaproducer(jsn={"collections": "instagram_users", "data": D},
                                  topic="instagram_bot")
                    logmaker(bot="insta", kind="log", description="instagram_users send to kafka 461")

                    # sakhtan e listi az followers and followings
                    user_ff = db.instagram_users_ff.find({"username": o["username"]}).count()
                    if user_ff == 0:
                        following_l = bot.get_user_following(o["username"])
                        if len(following_l) > 0:
                            follower_l = bot.get_user_followers(o["username"])
                            data2 = {"username": o["username"], "user_id": int(e), "following": following_l,
                                     "follower": follower_l}
                            i = db.instagram_users_ff.insert_one(data2)
                            kafkaproducer(jsn={"collections": "instagram_users_ff", "data": data2},
                                          topic="instagram_bot")
                            logmaker(bot="insta", kind="log", description="instagram_users_ff send to kafka 518")

                    print("\n")
                    print(str(g) + " - ")
                    g = g + 1
                    y = y + 1
                    print("owner:%s" % username)
                    print("username:%s" % o["username"])

                    f = open("resume.txt", "a+")
                    f.write('\n' + str(e))
                    f.close()

                    find = db.instagram_users.find({"username": o["username"]}).count()
                    if find == 0:
                        data={"username": o["username"], "crawlStatus": False}
                        i2 = db.instagram_users.insert(data)
                        kafkaproducer(jsn={"collections": "instagram_users", "data": data},
                                      topic="instagram_bot")
                        logmaker(bot="insta", kind="log", description="instagram_users send to kafka 480")


                    time.sleep(10)
                    if y > 70:
                        time.sleep(360)
                        y = 0
                        continue
                else:
                    continue
        else:
            d = {"owner": username, "follower list zero": True}
            o = db.instagram_skip_list.insert_one(d)
            kafkaproducer(jsn={"collections": "instagram_skip_list", "data": d},
                          topic="instagram_bot")
            logmaker(bot="insta", kind="log", description="instagram_skip_list send to kafka 497")






if __name__ == "__main__":
    bot.login()
    ip = input("""Choose one of them(Type number):
        1 - Resume...
        2 - type an username...
        3 - Auto find username from database...\n""")
    main(ip=int(ip))

